import { Component } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {

  isLoggedIn: boolean;


  constructor(private afAuth: AngularFireAuth, private router: Router, private authService: AuthService) {
    this.afAuth.authState.subscribe(user => {
      // convert user to True boolean value if it exists
      this.isLoggedIn = !!user;
    });
  }

  logout() {
    this.authService.logout();
  }

  
}
