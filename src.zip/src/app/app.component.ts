import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'angular-firebase-auth';

  showHeader = true;

  constructor(private router: Router) {
    // access router events
    this.router.events.pipe(
      // where event is confirmed to be a NavigationEnd
      filter( event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      // Subscribed to listen for specific components where header does not show
      this.showHeader = !(event.urlAfterRedirects === '/login' || event.urlAfterRedirects === '/register');

    });
  }
}
