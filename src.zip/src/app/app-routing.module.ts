import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { HomeComponent } from './pages/home/home.component';
import { RegisterComponent } from './pages/register/register.component';
import { SonglistComponent } from './pages/songlist/songlist.component';
import { YoutubeclipComponent } from './pages/youtubeclip/youtubeclip.component';
import { SearchComponent } from './pages/search/search.component';
import { MyaccountComponent } from './pages/myaccount/myaccount.component';
import { StatusesComponent } from './pages/statuses/statuses.component';

const routes: Routes = [{
  path:'',
  redirectTo:'login',
  pathMatch:'full'
},
{
  path:'login',
  component: LoginComponent
},
{
  path:'home',
  component: HomeComponent
},
{
  path:'search',
  component: SearchComponent
},
{
  path:'songlist',
  component: SonglistComponent
},
{
  path:'yt/:id',
  component: YoutubeclipComponent
},
{
  path:'statuses',
  component: StatusesComponent
},
{
  path:'myaccount',
  component: MyaccountComponent
},
{
  path:'register',
  component: RegisterComponent
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
