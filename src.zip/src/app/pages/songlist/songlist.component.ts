import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { AngularFireDatabase } from '@angular/fire/compat/database';
import { AuthService } from '../../services/auth.service';


@Component({
  selector: 'app-songlist',
  templateUrl: './songlist.component.html',
  styleUrl: './songlist.component.css'
})
export class SonglistComponent implements OnInit{

  
  items: Observable<any[]>;

  constructor(db: AngularFireDatabase, private authService: AuthService) {
    this.items = db.list('songs/').snapshotChanges().pipe(
      map(songs => 
        songs.map(song => ({ key: song.payload.key, ...song.payload.val() as {} }))
      ),
      map(items => this.shuffleArray(items))
    );
  }

  // Fisher-Yates shuffle algorithm to keep song list recommendations random
  private shuffleArray(songArray: any[]): any[] {
    for (let val1 = songArray.length - 1; val1 > 0; val1--) {
      const val2 = Math.floor(Math.random() * (val1 + 1));
      // console.log("Testing for " + val1 + ": " + val2);
      const changingVal = songArray[val1];
      songArray[val1] = songArray[val2];
      songArray[val2]= changingVal;
    }
    return songArray;
  }

  ngOnInit() {
    this.authService.isAuthenticated().subscribe(user => {
      if (user) {console.log(user);} 
      else {console.log("Authentication failed. Please log in.");}
    });
  }

  
}