import { Component } from '@angular/core';
import { DatabaseService } from '../../services/database.service';

@Component({
  selector: 'app-statuses',
  templateUrl: './statuses.component.html',
  styleUrl: './statuses.component.css'
})
export class StatusesComponent {

  users: any[];

  constructor(private db : DatabaseService){
    // getStatuses() really just returns all users, as there is no function
    // that does this. Further updates to project would rename this function
    // but it is currently leading to no errors or confusion.
    this.db.getStatuses().then(users => {
      // mapping users to array where their statuses can be accessed
      this.users = Object.keys(users).map(key => ({id: key, ...users[key]}));
    // console.log(this.users);
    // console.log(users);
  }).catch(err => {
    console.error('Error fetching statuses:', err);
  });
  }
}

