import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Observable, map } from 'rxjs';
import { AngularFireDatabase } from '@angular/fire/compat/database';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrl: './search.component.css'
})
export class SearchComponent{

  searchTerm: string = '';
  songs: Observable<any[]>;
  filteredSongs: Observable<any[]>

  constructor(db: AngularFireDatabase, private sanitizer: DomSanitizer, private authService: AuthService) {
    // fetch all songs
    this.songs = db.list('songs/').snapshotChanges().pipe(
      // Current RXJS best practice for piping data
      map(songs => 
        songs.map(song => ({ key: song.payload.key, ...song.payload.val() as {} }))
      )
    );
  }

  searchSongs() {
    // a query in the constructor returns all songs
    if (this.searchTerm) {
      // returned songs are being filtered by this function
      this.filteredSongs = this.songs.pipe(
        //songs are being filtered. Mapping songs that include the lowercase search term for simplicity
        map(songs => songs.filter(song => song.song.toLowerCase().includes(this.searchTerm.toLowerCase())))
      );
    } else {
      this.filteredSongs = null; // If no searchTerm, return no items.
    }
  }
}