import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Subscription, catchError, switchMap, throwError } from 'rxjs';
import { DatabaseService } from '../../services/database.service';

@Component({
  selector: 'app-myaccount',
  templateUrl: './myaccount.component.html',
  styleUrl: './myaccount.component.css'
})
export class MyaccountComponent {
  private subscription: Subscription;
  userObj : any = {
    "email" : "",
    "favSong" : "",
    "status" : ""
  };

  userID = "";
  status: string;

  constructor(private authService: AuthService, private dbService: DatabaseService) {
  }

  ngOnInit(): void {
    // get user email
    this.authService.returnEmail().pipe(
      switchMap(email => {
        if (email) {return this.authService.getUserIDByEmail(email);} 
        
        else {
          console.log('No email available');
          return throwError(() => new Error('Email not available'));
        }
      }),
      switchMap(userId => {
        if (userId) {
          // bind userID to local value
          this.userID = userId;
          return this.authService.getUserByUserId(userId);
        } 
        
        else {
          console.log('User ID not found');
          return throwError(() => new Error('User ID not available'));
        }
      }),
      catchError(error => {
        console.error('An error occurred:', error);
        return throwError(() => new Error('Error fetching user data'));
      })
    ).subscribe({
      // user has been found previously in the function so 'next' is used
      next: (user) => {
        // bind user to local userObj
        this.userObj = user;
        console.log('User object:', user);
      },
      error: (error) => console.error('Failed to fetch user object:', error)
    });
  }

  ngOnDestroy() {
    if (this.subscription) {this.subscription.unsubscribe();}
  }

  updateStatus(): void {
    // if there is no userID or status, OR is the status is longer than 100 char, fail.
    if (!this.userID || !this.status || this.status.length > 100) {
        window.alert('Missing userID or status invalid');

        // return null would imply that this is not a void function, although it would work presumably.
        // return; is best practice to exit a void function.
        return;
    }

    const updates = { status: this.status };

    // update user object with status attribute
    this.dbService.updateUser(this.userID, updates)
      .then(() => {
        // status attribute has been created OR overwritten successfully
        console.log('Status updated successfully:', this.status);
      })
      .catch(err => {
          console.error('Error encountered while updating status:', err);
      }
    );
  }
}
