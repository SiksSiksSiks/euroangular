import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription, throwError } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { AuthService } from '../../services/auth.service';
import { DatabaseService } from '../../services/database.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit, OnDestroy {
  private subscription: Subscription;
  email : string;
  randomSongId = 0;

  constructor(private authService: AuthService, private dbService: DatabaseService) {
    this.randomSongId = Math.floor(Math.random() * 40);
  }

  ngOnInit() {
    //get user email as observable
    this.subscription = this.authService.returnEmail()
      .pipe(
        switchMap(email => {
          //Bind email to local value
          this.email= email;
          //If success, check email exists in realtime user table.
          //If success but not in table, push email value to realtime user table
          //If error, isAuthenticated should log user out before not authenticated error is even logged
          return this.authService.isAuthenticated()
            .pipe(
              switchMap(isAuthenticated => {
                if (isAuthenticated) {
                  return this.dbService.emailExists(email);
                } else {
                  return throwError(() => new Error('Not authenticated'));
                }
              })
            )
          }
        )
      )
      .subscribe(
        result => console.log('User check or creation result:', result),
        error => console.error('An error occurred:', error)
      );
  }

  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
