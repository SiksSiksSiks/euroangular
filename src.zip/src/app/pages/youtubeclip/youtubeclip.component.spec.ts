import { ComponentFixture, TestBed } from '@angular/core/testing';

import { YoutubeclipComponent } from './youtubeclip.component';

describe('YoutubeclipComponent', () => {
  let component: YoutubeclipComponent;
  let fixture: ComponentFixture<YoutubeclipComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [YoutubeclipComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(YoutubeclipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
