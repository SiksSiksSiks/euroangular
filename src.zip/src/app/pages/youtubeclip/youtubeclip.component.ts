import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DatabaseService } from '../../services/database.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-youtubeclip',
  templateUrl: './youtubeclip.component.html',
  styleUrls: ['./youtubeclip.component.css']
})
export class YoutubeclipComponent {

  // This is the most complex Typescript file, where most of the database interactions occur
  showCountry = false;
  isDisabled = true;
  showSuccess = false;
  reviews : any[];

  // Most attributes are set to null or negative as a default.
  // They are immediately updated if needed when ratings are fetched
  rating: number = 0;
  rating2: number = 0;
  rating3: number = 0;
  confirmation: string = 'n'
  likeDislike: string = '';
  songID: string = '';
  userID: string = '';
  email: string;

  // Some attributes are set to Loading... as to allow a moment for the app to fetch song details
  songInfo = {
    song: 'Loading...',
    performer: 'Loading...',
    mp4_url: '',
    to_country: ''
  };

  constructor(
    private route: ActivatedRoute,
    private dbService: DatabaseService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    // Subcribe to paramMap observable to read the URL and take the ID attribute
    this.route.paramMap.subscribe(params => {
      // The OR condition here ensures that if there are issues obtaining the id,
      // an empty string will be returned instead of a null value which could lead to errors.
      // an empty string would presumably also lead to errors in this case, but it is good practice
      this.songID = params.get('id') || '';
      if (this.songID) {
        this.fetchSongInfoByKey(this.songID);

        //the url ID is the songID, so using that to get songInfo, now user info must be obtained.
        this.authService.returnEmail().subscribe(email => {
          // authService provides email and email is used to get userID
          if (email) {
            this.email = email;
            this.authService.getUserIDByEmail(email).subscribe(userID => {
              if (userID) {
                this.userID = userID;
                // once userID is obtained, the ratings table is queried for any existing ratings of the
                // current song
                this.fetchExistingRatings(userID, this.songID);
              } 
              
              else {console.log('User ID not found');}
            });
          } 
          else {console.log('No email available');}
        });
      } 
      else {console.log("Invalid or missing ID");}
    });
  }

  updateFavouriteSong(): void {
    // enure user and song info are valid
    if (!this.userID || !this.songInfo.song) {
        console.error('Missing userID or songInfo');
        return;
    }

    const updates = { favSong: this.songInfo.song };

    // This will either create and submit the favSong attribute or overwrite the current one.
    this.dbService.updateUser(this.userID, updates)
        .then(() => {
            console.log('Favorite song updated successfully:', this.songInfo.song);
        })
        .catch(err => {
            console.error('Error updating favorite song:', err);
        });
}

  confirmRating(){

    const ratingObject = {
      userID: this.userID,
      songID: this.songID,
      ratings: {
        melody: this.rating,
        production: this.rating2,
        overallEnjoyment: this.rating3,
        likeDislike: this.likeDislike
      }
    };

    // Show country info and disable confirmbutton
    this.showCountry = true;
    this.isDisabled = true;

    // Confirm ratings table 
    this.dbService.confirmRatingTable2(ratingObject).then(() => {
      console.log('Rating confirmed successfully');
    }).catch(err => {
      console.error('Error confirming rating:', err);
    });

    // update regular ratings table to prevent confirming again
    this.dbService.confirmRatingTable1(ratingObject).then(() => {
      console.log('Confirmation logged successfully');
    }).catch(err => {
      console.error('Error logging confirmation:', err);
    });

    this.showSuccess = true;
    
    setTimeout(()=>{
      // Hide success message
      this.showSuccess = false;
    }, 1000);
  }

  fetchExistingRatings(userID: string, songID: string): void {
    console.log("Fetching existing ratings...");
    this.dbService.getRatingsByUserAndSong(userID, songID).then(ratings => {
      if (ratings) {
        console.log("Ratings found.");
        // If there are any issues with the object being returned, 0 or negative is assumed.
        this.rating = ratings.melody || 0;
        this.rating2 = ratings.production || 0;
        this.rating3 = ratings.overallEnjoyment || 0;

        // For example, many ratings will not be confirmed and hense will not have the confirmed attribute
        // so 'n' is assumed
        this.confirmation = ratings.confirmed || 'n';
        console.log('Existing ratings loaded:', ratings);
        console.log('Confirmation: ' + this.confirmation);
      }

      else {
        console.log("No ratings found.");
        this.rating = 0;
        this.rating2 = 0;
        this.rating3 = 0;
        this.confirmation = 'n';
      }
      if (this.confirmation == 'y'){
        console.log("Song rating has been confirmed.");
        this.showCountry = true;
        this.isDisabled = true;
      }
      else {
        console.log("Song rating has NOT been confirmed.");
        this.isDisabled = false;
      }
    }).catch(err => {
      console.error('Error fetching existing ratings:', err);
    });

    
  }

  fetchOtherUserRatings(){
    console.log("Fetching other user ratings...");
    this.dbService.getOtherUserRatings(this.songID).then(data => {
      // save objects to array as key value pair where the key is id and the data is the value
      this.reviews = Object.keys(data).map(key => ({
        id: key,
        ...data[key]
      }));
      // console.log(this.reviews);
      // console.log(this.reviews[0]);

    }).catch(err => {
      console.error('Error fetching reviews:', err);
    });
  }

  //SetRating functions all perform the same tasks but focus on their respective rating
  setRating(star: number): void {
    this.rating = star;
    this.updateRating();
  }

  setRating2(star: number): void {
    this.rating2 = star;
    this.updateRating();
  }

  setRating3(star: number): void {
    this.rating3 = star;
    this.updateRating();
  }

  //Each setRating() function calls this function
  updateRating(): void {
    // ratingObject defined how it will be saved in the database
    const ratingObject = {
      userID: this.userID,
      songID: this.songID,
      ratings: {
        melody: this.rating,
        production: this.rating2,
        overallEnjoyment: this.rating3,
        likeDislike : this.likeDislike
      }
    };

    // call dbService function
    this.dbService.updateRating(ratingObject).then(() => {
      console.log('Rating updated successfully');
    }).catch(err => {
      console.error('Error updating rating:', err);
    });
  }

  fetchSongInfoByKey(key : string) : void {
    this.dbService.getSongInfoByKey("songs/" + key).then(songInfo => {
      // set local songInfo, this is the object displayed to users
      this.songInfo = songInfo;
      //console.log(songInfo);
    }).catch(err => {
      console.error('Error fetching song info:', err);
    });
  }
}
