import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  
  registrationForm: FormGroup = new FormGroup({
    'email': new FormControl(null, [Validators.required, Validators.email]),
    'password': new FormControl(null, Validators.required),
    'confirmPassword': new FormControl(null, Validators.required)
  });

  constructor(private authService: AuthService, private router: Router){
  }

  registerWithEmailAndPassword(){
    //Send registration for value to auth service. If error, log error.
    this.authService.registerWithEmailAndPassword(this.registrationForm.value).then(
      (res:any) =>{
        // success navigates user to login page
        this.router.navigateByUrl('\login');
      }
    ).catch(
      (err: any) =>{
        console.error(err);
      }
    )
  }
}
