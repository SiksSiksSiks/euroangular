import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router} from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { faGoogle } from '@fortawesome/free-brands-svg-icons';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit{

  signInForm: FormGroup = new FormGroup({
    'email': new FormControl(null, [Validators.required, Validators.email]),
    'password': new FormControl(null, Validators.required)
  });

  signUpForm: FormGroup;
  faGoogle = faGoogle;
  
  wrongCredentials = false;

  constructor(private authService: AuthService, private router: Router){
  }

  ngOnInit() {
    

    this.signUpForm = new FormGroup({
      'email': new FormControl(null),
      'password': new FormControl(null)
    });
  }

  signInWithGoogle() {
    //Sign in with google triggered. If success, direct to home. If error, show login error.
    this.authService.signInWithGoogle().then(
      (res:any) =>{
        this.router.navigateByUrl('\home');
      }
    ).catch(
      (err: any) =>{
        console.error("Error Found: " + err);
        this.wrongCredentials = true;
        setTimeout(() => {
          this.wrongCredentials = false;
        }, 3000);
      }
    )
  }

  signInWithEmailAndPassword(){
    //Log sign in form value. Send sign in form value to auth service. If error, show login error.
    console.log(this.signInForm.value);
    this.authService.signInWithEmailAndPassword(this.signInForm.value).then(
      (res:any) =>{
        this.router.navigateByUrl('home');
      }
    ).catch(
      (err: any) =>{
        console.error("Error Found: " + err);
        this.wrongCredentials = true;
        setTimeout(() => {
          this.wrongCredentials = false;
        }, 3000);
      }
    )
  }
}
