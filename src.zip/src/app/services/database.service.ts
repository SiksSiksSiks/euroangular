import { Injectable } from '@angular/core';
import { AngularFireDatabase } from '@angular/fire/compat/database';


@Injectable({
  providedIn: 'root'
})
export class DatabaseService {

  constructor(private db: AngularFireDatabase) { }

  // declared as async to return promise
  async getSongInfoByKey(key: string): Promise<any> {
    const path = "/" + key;
    // console.log("Path Query: " + path);

    // snapshot of path value is fetched here, await is used with Promise as it will either
    // return a result or an error.
    const sshot = await this.db.object(path).query.once('value');
    if (sshot.exists()) {return sshot.val();} 
    
    else {
        console.log("No data found for ", key);
        return null;
    }

    
  }



  async emailExists(email: string): Promise<any> {
    //console.log(email);

    // Reformat email string
    const safeEmail = email.replace(/\./g, ',');

    // Define path to user with email
    const usersRef = this.db.list('/users', ref => ref.orderByChild('email').equalTo(safeEmail));
    
    // Check for snapshot
    const sshot = await usersRef.query.once('value');
    
    // .exists() to avoid any 'truthy' response giving a false positive
    // All database retrieval snapshots follow this if else structure
    if (sshot.exists()) {
      console.log(email, " found");
      return true;
    } 
    
    else {

      // This else statement means that the user exists and has been authenticated
      // in Firebases user table, but the realtime database user table does not 
      // have a record of the email, so this must be pushed to database.
      console.log("No user found: ", email, ". Adding to database.");
      const newUser = { email : safeEmail };
      await usersRef.push(newUser);
      console.log("New user stored in user table with email:", email);
      return false;
    }
  }

  updateUser(userId: string, updates: Object): Promise<void> {
    // Used to either update status or favourite song
    // updates is a JSON Object
    return this.db.object('/users/' + userId).update(updates);
  }
  
  async updateRating(ratingObject: any): Promise<void> {
    // RatingObject has attributes, songID userID and ratings which has its own attributes indicating ratings
    const path = 'ratings/' + ratingObject.songID + '/' + ratingObject.userID;
    await this.db.object(path).set(ratingObject.ratings);
  }

  async confirmRatingTable2(ratingObject: any): Promise<void> {
    // When confirming rating, ratingobject is sent to the second ratings table
    // where the rating values are saved and cannot be overwritten in-app
    const path = 'confirmedRatings/' + ratingObject.songID + '/' + ratingObject.userID;
    await this.db.object(path).set(ratingObject.ratings);
  }

  async confirmRatingTable1(ratingObject: any): Promise<void> {
    // When confirming rating, confirmed attribute is updated to 'y'
    const confirmation = {"confirmed" : "y"}
    // This stops the user from be able to confirm a different rating on the same songID
    const path = 'ratings/' + ratingObject.songID + '/' + ratingObject.userID;
    await this.db.object(path).update(confirmation);
  }

  async getRatingsByUserAndSong(userID: string, songID: string): Promise<any> {
    // Used to fetch existing ratings for current song and user combination
    const path = "/ratings/" + songID + "/" + userID;
    console.log("Searching path:" + path);

    // Query db using path
    const sshot = await this.db.object(path).query.once('value');

    // if snapshot exists, return value. Else, log failure.
    if (sshot.exists()) {return sshot.val();} 
    
    else {
        console.log("No data found: ", path);
        return null;
    }
  }

  async getOtherUserRatings(songID): Promise<any> {
    const path = "/ratings/" + songID;
    console.log("Searching path:" + path);

    const sshot = await this.db.object(path).query.once('value');

    // if snapshot exists, return value. Else, log failure.
    if (sshot.exists()) {return sshot.val();} 
    
    else {
        console.log("No data found: ", path);
        return null;
    }
  }

  async getStatuses(): Promise<any> {
    const path = "/users/";
    console.log("Searching path:" + path);

    const sshot = await this.db.object(path).query.once('value');

    // if snapshot exists, return value. Else, log failure.
    if (sshot.exists()) {return sshot.val();} 
    
    else {
        console.log("No data found: ", path);
        return null;
    }
  }

}
