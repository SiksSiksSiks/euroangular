import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFireDatabase } from '@angular/fire/compat/database';
import { Router } from '@angular/router';
import { GoogleAuthProvider } from 'firebase/auth';
import { Observable, map, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  email : string;

  constructor(
    private afa: AngularFireAuth, 
    private router: Router, 
    private db: AngularFireDatabase) { }

  signInWithGoogle(){
    //Firebase function
    return this.afa.signInWithPopup(new GoogleAuthProvider());
  }

  registerWithEmailAndPassword(user : {email : string, password : string} ){
    //Firebase function
    return this.afa.createUserWithEmailAndPassword(user.email, user.password);
  }

  signInWithEmailAndPassword(user : {email : string, password : string} ){
    //Firebase function
    return this.afa.signInWithEmailAndPassword(user.email, user.password);
  }

  isAuthenticated() : Observable<boolean> {
    //AngularFireAuth checks authstate and either logs user email or logs out
    return this.afa.authState.pipe(
      tap(user => {
        if (user) {console.log(user.email + ' is logged in.');} 
        
        else {
          window.alert('No user is currently logged in. Logging out...');
          this.logout();
        }
      }),

      // map is defining what is being returned. In this case it will 
      // return a boolean value, whether or not user is null
      map(user => !!user)
    );
  }

  returnEmail() : Observable<string> {
    //Check authstate
    return this.afa.authState.pipe(
      tap(user => {
        //Verify user email by printing to console or logging out
        if (user) {console.log(user.email + ' is logged in.');} 
        
        else {
          this.logout();
          window.alert("You are being logged out: User could not be found.");
        }
      }),
      //if user exists, return email. else, return empty string
      map(user => {
        if (user) {return user.email;}

        else {return "";}
      })
    );
  }

  logout() {
    //user signout() from firebase
    this.afa.signOut().then(() => {
      //navigate to login
      this.router.navigate(['/login']);
    }).catch(err => {
      window.alert('Error Logging Out' + err);
    });
  }

  getUserIDByEmail(email: string) : Observable<string | null> {
    // replace '.' in email with ',' to avoid formatting issues
    // syntax replace(/STRING/g, 'newstring') g refers to global
    const safeEmail = email.replace(/\./g, ',');
  
    return this.db.list('/users', dblocation => dblocation.orderByChild('email').equalTo(safeEmail))
      .snapshotChanges().pipe(
        // result returns all matching email objects in an array
        // there should be only one that matches safeEmail
        // so element 0 is our target user object
        map(result => {
          const obj = result[0];

          if (obj){return obj.payload.key;}

          else {return null;}
        }),

        tap(userId => {
          if (userId) {console.log('User ID found: ' + userId + ' for email: ' + email );} 

          else {console.log('No user ID found for email: ' + email);}
        })
      );
  }

  getUserByUserId(userId: string) : Observable<any> {
    // return user object from path
    return this.db.object('/users/' + userId ).valueChanges();
  }
}
