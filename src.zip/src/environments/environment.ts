export const environment = {
    production: false,
    firebaseConfig: {
        apiKey: "AIzaSyCTA6HuMLHcooYdn4OaMxRf8dmkkvhOVf0",
        authDomain: "euro-vision-f5f4d.firebaseapp.com",
        databaseURL: "https://euro-vision-f5f4d-default-rtdb.europe-west1.firebasedatabase.app",
        projectId: "euro-vision-f5f4d",
        storageBucket: "euro-vision-f5f4d.appspot.com",
        messagingSenderId: "687781575708",
        appId: "1:687781575708:web:3794cf22da7ab7780733d9",
      }
};
